# Student Management RESTful API

A simple RESTful API built with Node.js, Express, and MongoDB for managing student records.

## Setup

1. Install dependencies: